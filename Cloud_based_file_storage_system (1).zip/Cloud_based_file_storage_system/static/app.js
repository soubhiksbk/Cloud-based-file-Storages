const dropArea = document.getElementById("drop-area");
const fileInput = document.getElementById("file-input");
const uploadBtn = document.getElementById("upload-btn");
const submitBtn = document.getElementById("submit-btn");
const uploadMessage = document.getElementById("upload-message");
let selectedFile = null;

// Trigger file input when the "Choose File" button is clicked
uploadBtn.addEventListener("click", () => {
    fileInput.click();
});

// Store selected file when chosen
fileInput.addEventListener("change", () => {
    selectedFile = fileInput.files[0];
    uploadMessage.innerText = `Selected: ${selectedFile.name}`;
});

// Handle drag and drop
dropArea.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropArea.style.backgroundColor = "#f1f1f1";
});

dropArea.addEventListener("dragleave", () => {
    dropArea.style.backgroundColor = "#fafafa";
});

dropArea.addEventListener("drop", (event) => {
    event.preventDefault();
    dropArea.style.backgroundColor = "#fafafa";
    selectedFile = event.dataTransfer.files[0];
    uploadMessage.innerText = `Selected: ${selectedFile.name}`;
});

// Handle file upload
submitBtn.addEventListener("click", () => {
    if (!selectedFile) {
        uploadMessage.innerText = "No file selected!";
        return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    fetch("/upload", {
        method: "POST",
        body: formData,
    })
        .then((response) => response.json())
        .then((data) => {
            uploadMessage.innerText = data.message || "File uploaded successfully!";
        })
        .catch((error) => {
            uploadMessage.innerText = `Upload failed: ${error.message}`;
        });
});

// Handle file download
const downloadBtn = document.getElementById("download-btn");
const downloadFilename = document.getElementById("download-filename");
const downloadLinkDiv = document.getElementById("download-link");

downloadBtn.addEventListener("click", () => {
    const filename = downloadFilename.value.trim();
    if (filename) {
        fetch(`/download/${filename}`)
            .then((response) => response.json())
            .then((data) => {
                if (data.url) {
                    downloadLinkDiv.innerHTML = `<a href="${data.url}" target="_blank">Download ${filename}</a>`;
                } else {
                    downloadLinkDiv.innerText = "Error: " + data.error;
                }
            })
            .catch((error) => {
                downloadLinkDiv.innerText = "Download failed: " + error.message;
            });
    } else {
        downloadLinkDiv.innerText = "Please enter a valid filename.";
    }
});
