import os
from flask import Flask, request, jsonify, send_from_directory, render_template
import boto3
from botocore.exceptions import NoCredentialsError

app = Flask(__name__, template_folder='templates', static_folder='static')

BUCKET_NAME = 'my-flask-storage-bucket-2025'
AWS_REGION = 'us-east-1'
s3 = boto3.client('s3', region_name=AWS_REGION)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    print(f"Request files: {request.files}")  # To log what is coming in the request
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})

    file = request.files['file']
    print(f"Uploaded file: {file.filename}")  # To log the file name

    if file.filename == '':
        return jsonify({"error": "No selected file"})

    try:
        s3.upload_fileobj(file, BUCKET_NAME, file.filename)
        return jsonify({"message": f"File {file.filename} uploaded successfully!"})
    except NoCredentialsError:
        return jsonify({"error": "Credentials not available"})
    except Exception as e:
        return jsonify({"error": str(e)})



@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    try:
        file_url = s3.generate_presigned_url('get_object',
                                             Params={'Bucket': BUCKET_NAME, 'Key': filename},
                                             ExpiresIn=3600)

        return jsonify({"url": file_url})
    except Exception as e:
        return jsonify({"error": str(e)})


if __name__ == '__main__':
    app.run(debug=True)
